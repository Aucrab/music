package com.example.musicplayer.online;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.example.musicplayer.R;

public class online extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online);


        WebView webView =(WebView) findViewById(R.id.webView);
//        FMAViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });

        webView.setWebViewClient(new downloadTask(webView.getContext()));
        WebSettings s = webView.getSettings();
        s.setSaveFormData(false);
        s.setUseWideViewPort(true);
        s.setJavaScriptEnabled(true);
//        webView.setWebChromeClient(new WebChromeClient() {
//            public void onProgressChanged(WebView view, int progress) {
//                //Activity和Webview根据加载程度决定进度条的进度大小
//                //当加载到100%的时候 进度条自动消失
//
//                getContext().setProgress(progress * 100);
//            }
//        });
        webView.loadUrl("https://freemusicarchive.org/home");


    }
}