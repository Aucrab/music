package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.musicplayer.DB.MyDatabaseHelper;
import com.example.musicplayer.local.local;
import com.example.musicplayer.online.online;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createDB();
        clickedButtonLocal();
        clickedButtonOnline();

    }


    private void createDB()
    {
        MyDatabaseHelper dbHelper;
        dbHelper = new MyDatabaseHelper(this, "Music.db", null, 1);
        dbHelper.getWritableDatabase();
}

    private void clickedButtonLocal()
    {
        Button buttonLocal = (Button) findViewById(R.id.buttonLocal);
        buttonLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, local.class);
                startActivity(intent);
            }
        });
    }
    private void clickedButtonOnline()
    {
        Button buttonOnline = (Button) findViewById(R.id.buttonOnline);
        buttonOnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, online.class);
                startActivity(intent);
            }
        });
    }


}

