package com.example.musicplayer.online;

import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.example.musicplayer.DB.MyDatabaseHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class downloadProcess extends Service implements Runnable{

    private String URL_str;						//网络歌曲的路径
    private File download_file;					//下载的文件
    private int total_read = 0;					//已经下载文件的长度（以字节为单位）
    private int readLength = 0;					//一次性下载的长度（以字节为单位）
    private int music_length = 0;					//音乐文件的长度（以字节为单位）
    private boolean flag = false;					//是否停止下载，停止下载为true
    private Thread downThread;					//下载线程
    private String musicName;
    private String musicAuthor;
    private String musicFile;
    private Context context;
    private MyDatabaseHelper dbHelper;

    public downloadProcess(Context context,String url,String musicFile,String musicName,String musicAuthor){
        this.context = context;
        this.URL_str = url;
        this.musicName = musicName;
        this.musicAuthor = musicAuthor;
        this.musicFile = musicFile;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        downThread = new Thread(this);			//初始化下载线程
        downThread.run();
    }



    @Override
    public void onDestroy() {
        flag = true;//停止下载
    }

    @Override
    public void run(){


        try {
            String dirName = "";
            //SD卡具有读写权限、指定附件存储路径为SD卡上指定的文件夹
            dirName = Environment.getExternalStorageDirectory() + "/Music/";
            Log.d("fan", "wjj地址:" + dirName);
            File f = new File(dirName);
            String fileName = musicFile;
            fileName = dirName + fileName;
            File file = new File(fileName);
            if (file.exists()) {    //如果目标文件已经存在
                //file.delete();    //则删除旧文件
            } else {
                dbHelper = new MyDatabaseHelper(context, "Music.db", null, 1);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("url", URL_str);
                values.put("file", musicFile);
                values.put("author", musicAuthor);
                values.put("name", musicName);
                values.put("addr", fileName);
                db.insert("Music", null, values);
                values.clear();
                db.close();

            //1K的数据缓冲
            byte[] bs = new byte[1024];
            //读取到的数据长度
            int len;
            try {
                //通过文件地址构建url对象
                URL url = new URL(URL_str);
                //获取链接
                //URLConnection conn = url.openConnection();
                //创建输入流
                InputStream is = url.openStream();
                //获取文件的长度
                //int contextLength = conn.getContentLength();
                //输出的文件流
                OutputStream os = new FileOutputStream(file);
                //开始读取
                while ((len = is.read(bs)) != -1) {
                    os.write(bs, 0, len);
                }

                //完毕关闭所有连接
                os.close();
                is.close();
            } catch (MalformedURLException e) {
                fileName = null;
                System.out.println("创建URL对象失败");
                throw e;
            } catch (FileNotFoundException e) {
                fileName = null;
                System.out.println("无法加载文件");
                throw e;
            } catch (IOException e) {
                fileName = null;
                System.out.println("获取连接失败");
                throw e;
            }
            if (file.exists()) {    //如果目标文件已经存在
                Toast.makeText(this, "下载成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "下载失败", Toast.LENGTH_SHORT).show();
            }
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
