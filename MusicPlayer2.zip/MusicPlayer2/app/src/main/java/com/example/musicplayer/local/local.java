package com.example.musicplayer.local;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.musicplayer.DB.MyDatabaseHelper;
import com.example.musicplayer.MainActivity;
import com.example.musicplayer.R;
import com.example.musicplayer.online.downloadProcess;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class local extends AppCompatActivity {

    List<Map<String,Object>> musicMapList=new ArrayList<>();
    private MediaPlayer player = new MediaPlayer();
    int muiscPosition=0;
    int type=1;
    private boolean suspended=true;
    private boolean jump=false;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what)
            {
                case 1:
                    Log.d("fan", "开始循环");
                    int TIME=player.getDuration();
                    Log.d("fan", "总时长"+TIME);
                    int time=player.getCurrentPosition();
                    Log.d("fan", "已经播放"+time);
                    int p=(time*100)/TIME;

                    Log.d("fan", "开始循环"+p);
                    SeekBar seekBarTimeline=(SeekBar) findViewById(R.id.seekBarTimeline);
                    seekBarTimeline.setProgress(p);
clickedButtonSwitchType();
                    switchTheMusic();

                    buttonChange();
                    //buttonPlay.setText("▶");
                    //buttonPlay.setText("▌▌");

                    break;
                default:
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private  Runnable task=new Runnable() {
        @Override
        public void run() {
            handler.sendEmptyMessage(1);
            handler.postDelayed(this,1000);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local);
        searchDB();



        //Button play = findViewById(R.id.play);
        //Button pause = findViewById(R.id.pause);
        //Button stop = findViewById(R.id.stop);
        //play.setOnClickListener(this);
        //pause.setOnClickListener(this);
        //stop.setOnClickListener(this);
        if(ContextCompat.checkSelfPermission(local.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(local.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }else{
            initMediaPlayer();
        }

        /*player.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
            @Override
            public void onCompletion(MediaPlayer mp) {
                muiscPosition=muiscPosition+1;
                Log.d("fan", "下一曲，歌曲标号"+muiscPosition);
                changeMusic();
            }
        });*/
        handler.postDelayed(task,1000);
        clickedSeekBarTimeline();
        clickedButtonSwitchType();
        clickedButtonPlay();
        //clickedButtonPause();
        clickedButtonStop();
        clickedButtonLast();
        clickedButtonNext();




    }



    private void initMediaPlayer(){
        try{
            String addr=musicMapList.get(muiscPosition).get("addr").toString();
            Log.d("fan", "地址。。。"+addr);
            //File file = new File(Environment.getExternalStorageDirectory()+"/Music","music.mp3");

            player.reset();
            player.setDataSource(addr);
            //player.reset();
            player.prepare();
            TextView musicName= (TextView) findViewById(R.id.musicName);
            TextView musicAuthor= (TextView) findViewById(R.id.musicAuthor);
            musicName.setText(musicMapList.get(muiscPosition).get("name").toString());
            musicAuthor.setText(musicMapList.get(muiscPosition).get("author").toString());
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case 1:
                if(grantResults.length>0
                        &&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    initMediaPlayer();
                }else{
                    Toast.makeText(this, "用户没有授予读取外部存储的权限",Toast.LENGTH_SHORT)
                            .show();
                    finish();
                }
                break;
            default:
                break;
        }
    }


    private void clickedButtonPlay()
    {
        Button buttonPlay = (Button) findViewById(R.id.play);
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(suspended==true)
                {
                    if (!player.isPlaying()) {
                        player.start();//开始播放
                    }
                    //suspended=false;
                    //buttonPlay.setText("▌▌");
                }
                else if(suspended==false)
                {
                    if(player.isPlaying()){
                        player.pause();//暂停播放
                    }
                    //suspended=true;
                    //buttonPlay.setText("▶");
                    //buttonPlay.setText("▌▌");
                }
            }
        });
    }
    private void clickedButtonStop()
    {
        Button buttonStop = (Button) findViewById(R.id.stop);
        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player.isPlaying()){
                    player.reset();//停止播放
                    initMediaPlayer();
                }
            }
        });
    }
    private void clickedButtonLast()
    {
        Button buttonLast = (Button) findViewById(R.id.last);
        buttonLast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num=musicMapList.size();
                Log.d("fan", "曲目个数"+num);
                muiscPosition=(muiscPosition+num-1)%num;
                Log.d("fan", "下一曲，歌曲标号"+muiscPosition);
                changeMusic();
            }
        });
    }
    private void clickedButtonNext()
    {
        Button buttonNext = (Button) findViewById(R.id.next);
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num=musicMapList.size();
                Log.d("fan", "曲目个数"+num);
                muiscPosition=(muiscPosition+1)%num;
                Log.d("fan", "下一曲，歌曲标号"+muiscPosition);
                changeMusic();
            }
        });
    }
    /*private void clickedButtonPause()
    {
        Button buttonPause = (Button) findViewById(R.id.pause);
        buttonPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player.isPlaying()){
                    player.pause();//暂停播放
                }
            }
        });
    }*/

    /*@Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.play:
                //点击了播放按钮
                if(!player.isPlaying()){
                    player.start();//开始播放
                }
                break;
            case R.id.pause:
                //点击了暂停按钮
                if(player.isPlaying()){
                    player.pause();//暂停播放
                }
                break;
            case R.id.stop:
                //点击了停止按钮
                if(player.isPlaying()){
                    player.reset();//停止播放
                    initMediaPlayer();
                }
                break;
        }
    }*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(player!=null){
            player.stop();
            player.release();
        }
    }
    protected void onPause() {

        super.onPause();
        handler.removeCallbacks(task);
    }


   /*private  void refresh()
   {
       new Thread(new Runnable() {
           @Override
           public void run() {
               int time=player.getCurrentPosition();
               //使用handler向主线程回传
               Message message = Message.obtain();
               message.what = 1;
               message.obj = time;
               handler.sendMessage(message);
           }
       }).start();
   }*/


    void deleteDB(int p)
    {
        if(player.isPlaying()){
            player.reset();//停止播放
            initMediaPlayer();
        }

        MyDatabaseHelper dbHelper ;
        dbHelper = new MyDatabaseHelper(this, "Music.db", null, 1);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String ID=musicMapList.get(p).get("id").toString();
        db.delete("music", "id = ?", new String[]{ID});
        File file = new File(musicMapList.get(p).get("addr").toString());
        if (file.exists()) {    //如果目标文件已经存在
            file.delete();    //则删除旧文件
        }


    }




    void searchDB()
    {
        musicMapList.clear();
        MyDatabaseHelper dbHelper;
        dbHelper = new MyDatabaseHelper(this, "Music.db", null, 1);
        ListView musicList=(ListView)findViewById(R.id.musicList);
        //List<Map<String,Object>> musicMapList=new ArrayList<>();
        //List<String> notebookListText = new ArrayList<String>();
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // 查询Book表中所有的数据
        Cursor cursor = db.query("music", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                // 遍历Cursor对象，取出数据并打印
                //id integer primary key autoincrement,
                 //       url text,file text unique,author text,name text,addr text
                int idint= cursor.getColumnIndex("id");
                int urlint=cursor.getColumnIndex("url");
                int fileint=cursor.getColumnIndex("file");
                int authorint=cursor.getColumnIndex("author");
                int nameint=cursor.getColumnIndex("name");
                int addrint=cursor.getColumnIndex("addr");

                int id=cursor.getInt(idint);
                String url = cursor.getString(urlint);
                String file = cursor.getString(fileint);
                String author = cursor.getString(authorint);
                String name = cursor.getString(nameint);
                String addr = cursor.getString(addrint);

                //System.out.print(id+node+author+time);

                File file1 = new File(addr);
                if(file1.exists())
                {    //如果目标文件已经存在
                    Map<String,Object> map= new HashMap<>();
                    map.put("name",name);
                    map.put("author",author);
                    map.put("addr",addr);
                    map.put("id",id);
                    musicMapList.add(map);
                }


                /*Map<String,Object> map= new HashMap<>();
                map.put("name",name);
                map.put("author",author);
                map.put("addr",addr);
                musicMapList.add(map);*/


                //notebookListText.add(title);

            } while (cursor.moveToNext());
        }
        cursor.close();
        //Collections.reverse(notebookListText);
        //ArrayAdapter<String> notbookText1 = new ArrayAdapter<String>(this,R.layout.list_item,notebookListText);//listdata和str均可

        SimpleAdapter  musicSimpleAdapter=new SimpleAdapter(this,
                musicMapList,
                R.layout.music_list,
                new String[]{"name","author"},
                new int[]{R.id.name,R.id.author});
        musicList.setAdapter(musicSimpleAdapter);

        musicList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                muiscPosition=position;
                Log.d("fan", "歌曲标号"+muiscPosition);
                Log.d("fan", "歌曲标号"+musicMapList.get(muiscPosition).get("addr").toString());
                changeMusic();


            }
        });
        musicList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                deleteDB(position);
                searchDB();
                return false;
            }
        });

    }

    private void changeMusic()
    {
        if(player.isPlaying()){
            player.reset();//停止播放
        }
        initMediaPlayer();
        if(!player.isPlaying()){
            player.start();//开始播放
        }
    }



    private void clickedSeekBarTimeline()
    {
        SeekBar seekBarTimeline=(SeekBar) findViewById(R.id.seekBarTimeline);
        seekBarTimeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int TIME=player.getDuration();
                Log.d("fan", "总时长"+TIME);
                int  t = TIME/100;
                int tt=t*progress;
                int p=tt;
                //handler.postDelayed(task,1000);
                if(jump==true)
                {
                    Log.d("fan", "跳转至"+p);
                    player.seekTo(p);
                    jump=false;
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.d("fan", "开始移动+++++++++++++");
                jump=true;
                //handler.removeCallbacks(task);

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //if(jump==true)
                //handler.removeCallbacks(task);

            }
        });
    }

    private void clickedButtonSwitchType()
    {
        Button switchType = (Button) findViewById(R.id.switchType);
        switchType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type==1)
                {
                    type=2;
                    Log.d("fan", "单曲循环");
                    switchType.setText("单曲循环");
                }
                else if(type==2)
                {
                    type=3;
                    Log.d("fan", "随机循环");
                    switchType.setText("随机循环");
                }
                else if(type==3)
                {
                    type=1;
                    Log.d("fan", "全部循环");
                    switchType.setText("全部循环");
                }

            }
        });
    }

    private  void switchTheMusic()
    {
        if(type==1)
        {
            cycleAll();
        }
        if(type==2)
        {
            cycleOne();
        }
        if(type==3)
        {
            cycleRandom();
        }

    }

    private void cycleAll()
    {
        SeekBar seekBarTimeline=(SeekBar) findViewById(R.id.seekBarTimeline);
        if(seekBarTimeline.getProgress()==99)
        {
            int num=musicMapList.size();
            Log.d("fan", "曲目个数"+num);
            muiscPosition=(muiscPosition+1)%num;
            Log.d("fan", "下一曲，歌曲标号"+muiscPosition);
            changeMusic();
        }
    }
    private void cycleOne()
    {
        SeekBar seekBarTimeline=(SeekBar) findViewById(R.id.seekBarTimeline);
        if(seekBarTimeline.getProgress()==99)
        {
            changeMusic();
        }
    }
    private void cycleRandom()
    {
        SeekBar seekBarTimeline=(SeekBar) findViewById(R.id.seekBarTimeline);
        if(seekBarTimeline.getProgress()==99)
        {
            int num=musicMapList.size();
            int n=(int)(1+Math.random()*(num-1+1));
            Log.d("fan", "下一首跳转"+n+"首歌曲");
            Log.d("fan", "曲目个数"+num);
            muiscPosition=(muiscPosition+n)%num;
            Log.d("fan", "下一曲，歌曲标号"+muiscPosition);
            changeMusic();
        }
    }

    private void buttonChange()
    {
        Button buttonPlay = (Button) findViewById(R.id.play);
        if(player.isPlaying())
        {
            buttonPlay.setText("▌▌");
            suspended=false;
        }
        else
        {
            buttonPlay.setText("▶");
            suspended=true;
        }
    }
/*
<Button
            android:id="@+id/pause"
            android:layout_width="0dp"
            android:layout_weight="2"
            android:layout_height="wrap_content"
            android:text="▌▌"/>
*/

}


