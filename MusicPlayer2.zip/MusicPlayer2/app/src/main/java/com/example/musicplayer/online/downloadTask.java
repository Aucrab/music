package com.example.musicplayer.online;

import android.content.Context;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class downloadTask extends WebViewClient
{
    private Context context;

    public downloadTask(Context context) {
        this.context = context;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        String urlStr = "";                                    //存放解码后的url

        //如果链接是下载top100.cn中的mp3文件
        if (url.substring(url.length() - 4).equals(".mp3")) {

            String musicAuthor = "未知艺术家";
            Log.i("info",url);//得到音乐文件的全名（包括后缀）
            urlStr = url;
            String s1[] = urlStr.split("/");
            String musicName = s1[s1.length - 1];
            String s2[] = musicName.split("\\?");
            String musicFile = s2[s2.length - 2];
            String s3[] = musicFile.split("_-_");
            musicName = s3[s3.length - 1];
            String s4[] = musicName.split("\\.");
            musicName = s4[s4.length - 2];
            if(s3.length - 3 >= 0)
                musicAuthor = s3[s3.length - 3];

            Log.i("info", "music file:" + musicFile);
            Log.i("info", "music name:" + musicName);
            Log.i("info","music author:" + musicAuthor);

//            将下载链接和文件名传递给下载模块
//            Intent intent = new Intent(this.context, DownService.class);
//            intent.putExtra("url", url);
//            intent.putExtra("musicName", musicName);
//            context.startService(intent);
            new Thread(new downloadProcess(context,url,musicFile,musicName,musicAuthor)).start();

        }
        return super.shouldOverrideUrlLoading(view, url);
    }
}
